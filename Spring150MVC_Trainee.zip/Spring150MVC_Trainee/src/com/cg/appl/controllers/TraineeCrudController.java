package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;


//htttp://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class TraineeCrudController
{
	private TraineeServices services;
	List<String> domainList;	
	List<String> locations;
	//List<Integer> traineeIDs;
	
	@PostConstruct
	public void intialize()
	{
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations = new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Banglore");
		locations.add("Delhi");
		locations.add("Chennai");
		
		//traineeIDs = new ArrayList<>();
		
	}
	
	
		@Resource(name="TraineeService") //service injection in controller
		public void setTraineeServices(TraineeServices services)
		{
			this.services  = services;
		}
		
		@RequestMapping("/welcome.do")
		public ModelAndView getWelcomePage()
		{
			ModelAndView model = new ModelAndView("welcome");
			return model;
		}	
	
	
		@RequestMapping("/enterTraineeNo.do")
		public ModelAndView enterTraineeNo()
		{
			ModelAndView model = new ModelAndView("enterTraineeNo");
			return model;
		}
		
		//
		@RequestMapping("/getTraineeDetails.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo)
		{
			System.out.println("Trainee No : "+traineeNo);
			
			Trainee trainee;
			ModelAndView model = null;
			try {
				trainee = services.getTraineeDetails(traineeNo);
				
				model = new ModelAndView("traineeDetails");
				model.addObject("traineeDetails",trainee);
				
			} catch (TraineeException e) {				
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());
			}			
			return model;
		}
		
		@RequestMapping("/listAllTrainee.do")
		public ModelAndView listAllTrainees()
		{
			
			ModelAndView model = null;
			try 
			{				
				List<Trainee> tList = services.getAllTrainee();
				model = new ModelAndView("listAllTrainees");
				model.addObject("trainees", tList);
			}
			catch (TraineeException e)
			{
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());				
			}			 
			return model;
		}
		
		
		@RequestMapping("entryForm.do")
		public ModelAndView getEntryForm()
		{
			ModelAndView model = new ModelAndView("entryForm");
			model.addObject("trainee", new Trainee());
			model.addObject("domains",domainList);
			model.addObject("locations",locations);
			/*
			 * object creation for submitEntryForm.do which is fetched in @ModelAttribute
			 * */
			return model;
		}
		@RequestMapping("submitEntryFrom.do")
		public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee, BindingResult result) 	//generates trainee obj based on jsp page
		{
			ModelAndView model  = new ModelAndView();
			
			if(result.hasErrors())
			{
				//System.out.println("bhsdfbhlsdvbhsdv");
				//model.addObject("trainee", new Trainee());
				model.addObject("domains",domainList);
				model.addObject("locations",locations);
				model.setViewName("entryForm");
				return model;
			}
			else
			{	
				try {
					Trainee traineeResponse = services.insertNewTrainee(trainee);			
					
					model.setViewName("successInsert");
					model.addObject("trainee", traineeResponse);
					
				} catch (TraineeException e) {
					model.setViewName("errorInsert");
					model.addObject("errMsg", "Record insertion failure !!!"+e.getMessage());
				}
				return model;
			}
		}
		
		/*@RequestMapping("/updateTrainee.do")
		public ModelAndView updateTrainee(@RequestParam("id") int traineeNo)
		{
			ModelAndView model  = new ModelAndView();
			model.addObject("errMsg", "Dummy Message trainee ID : "+traineeNo);
			model.setViewName("error");
			return model;
		}*/
				
		@RequestMapping("/enterTraineeNoToDelete.do")
		public ModelAndView enterTraineeNoToDelete()
		{
			ModelAndView model = new ModelAndView("deleteTrainee");
			return model;
		}
			
		@RequestMapping("/deleteTraineeDetails.do")
		public ModelAndView deleteTrainee(@RequestParam("traineeNo") int traineeNo)
		{
			ModelAndView model  = new ModelAndView();
			try {
				boolean isDeleted = services.deleteTraineeDetails(traineeNo);
				if(isDeleted)
				{
					System.out.println("Trainee "+traineeNo+" deleted !!!");
					model.setViewName("welcome");
				}
				else
				{
					model.addObject("errMsg", "Unable to delete Trainee : "+traineeNo);
					model.setViewName("error");
				}
				
				
			} catch (TraineeException e) {
				model.addObject("errMsg", "Unable to delete Trainee : "+traineeNo);
				model.setViewName("error");
			}			
			return model;
		}
		
		@RequestMapping("/showTraineeDetailsToModify.do") 	//here input parameter must be mapped to textfields in login.jsp file form
		public ModelAndView getTraineeDetailsToModify(@RequestParam("traineeNo") int traineeNo)
		{
			System.out.println("Trainee No : "+traineeNo);
			
			Trainee trainee;
			ModelAndView model = null;
			try {
				trainee = services.getTraineeDetails(traineeNo);
				
				model = new ModelAndView("traineeDetails");
				model.addObject("traineeDetails",trainee);
				
			} catch (TraineeException e) {				
				model = new ModelAndView("error");
				model.addObject("errMsg", e.getMessage());
			}			
			return model;
		}
		@RequestMapping("/updateTraineeDetails.do")
		public ModelAndView updateTraineeDetails(@RequestParam("traineeNo") int traineeNo,
				@RequestParam("traineeName") String traineeName,@RequestParam("traineeDomain") String traineeDomain,
				@RequestParam("traineeLocation") String traineeLocation)
		{
			Trainee trainee = new Trainee();
			trainee.setTraineeId(traineeNo);
			trainee.setTraineeName(traineeName);
			trainee.setTraineeDomain(traineeDomain);
			trainee.setTraineeLocation(traineeLocation);
			
			ModelAndView model  = new ModelAndView();
			try {
				boolean isUpdated = services.updateTraineeDetails(trainee);
				if(isUpdated)
				{
					System.out.println("Trainee "+traineeNo+" updated !!!");
					model.setViewName("welcome");
				}
				else
				{
					model.addObject("errMsg", "Unable to update Trainee : "+traineeNo);
					model.setViewName("error");
				}
				
				
			} catch (TraineeException e) {
				model.addObject("errMsg", "Unable to update Trainee : "+traineeNo);
				model.setViewName("error");
			}			
			return model;
		}
}